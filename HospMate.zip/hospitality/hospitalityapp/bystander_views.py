from django.contrib.auth.models import User
from django.views.generic import TemplateView , View
from django.shortcuts import render

from hospitalityapp.models import bystander, bystander_app


class IndexView(TemplateView):
    template_name = 'bystander/bystander_index.html'
    
class view_app(TemplateView):
    template_name = 'bystander/view_booking.html'
    def get_context_data(self, **kwargs):
        context = super(view_app,self).get_context_data(**kwargs)
        by = bystander.objects.get(user_id=self.request.user.id)
        hoo = bystander_app.objects.filter(bystander_id = by.id, status='added')

        context ['hoo'] = hoo
        return context

class app_approve(View):
    def dispatch(self, request, *args, **kwargs):
        id = request.GET['id']
        h = bystander_app.objects.get(id=id)
        h.status='Booking Confirm'
        h.save()
        return render(request,'bystander/bystander_index.html',{'message':"  Booking Confirmed"})

class view_b_booking(TemplateView):
    template_name = 'bystander/view_b_booking.html'
    def get_context_data(self, **kwargs):
        context = super(view_b_booking,self).get_context_data(**kwargs)
        by = bystander.objects.get(user_id=self.request.user.id)
        bb = bystander_app.objects.filter(bystander_id = by.id, status='Booking Confirm')

        context ['bb'] = bb
        return context