from django.urls import path
from hospitalityapp.admin_views import IndexView, bystander_approve, bystander_reject,\
    bystander_verify, hospital_approve, hospital_reject, hospital_verify, view_bystander, \
        view_hospital, view_user, view_hbooking, view_b_booking


urlpatterns = [

    path('',IndexView.as_view()),
    path('hospital_verify',hospital_verify.as_view()),
    path('approve',hospital_approve.as_view()),
    path('reject',hospital_reject.as_view()),
    path('bystander_verify',bystander_verify.as_view()),
    path('bystander_approve',bystander_approve.as_view()),
    path('bystander_reject',bystander_reject.as_view()),
    path('view_hospital',view_hospital.as_view()),
    path('view_bystander',view_bystander.as_view()),
    path('view_user',view_user.as_view()),
    path('view_hbooking',view_hbooking.as_view()),
    path('view_b_booking',view_b_booking.as_view()),

        







    ]
def urls():
    return urlpatterns, 'admin', 'admin'