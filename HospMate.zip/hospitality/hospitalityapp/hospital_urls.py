from django.urls import path
from hospitalityapp.hospital_views import IndexView, view_bystander, view_user, view_booking, app_approve

urlpatterns = [

    path('',IndexView.as_view()),
    path('view_bystander',view_bystander.as_view()),
    path('view_user',view_user.as_view()),
    path('view_booking',view_booking.as_view()),
    path('app_approve',app_approve.as_view()),




    

    ]
def urls():
    return urlpatterns, 'hospital', 'hospital'