from django.urls import path
from hospitalityapp.bystander_views import IndexView, view_app, app_approve, view_b_booking

urlpatterns = [

    path('',IndexView.as_view()),
    path('view_app',view_app.as_view()),
    path('app_approve',app_approve.as_view()),
    path('view_b_booking',view_b_booking.as_view()),




    

    ]
def urls():
    return urlpatterns, 'bystander', 'bystander'