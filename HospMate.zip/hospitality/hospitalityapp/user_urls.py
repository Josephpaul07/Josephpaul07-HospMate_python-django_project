from django.urls import path
from hospitalityapp.user_views import IndexView, view_hospital, view_bystanders,add_app, add_app_hos, view_hbooking, view_b_booking

urlpatterns = [

    path('',IndexView.as_view()),
    path('view_hospital',view_hospital.as_view()),
    path('view_bystanders',view_bystanders.as_view()),
    path('add_app',add_app.as_view()),
    path('add_app_hos',add_app_hos.as_view()),
    path('view_hbooking',view_hbooking.as_view()),
    path('view_b_booking',view_b_booking.as_view()),





    ]
def urls():
    return urlpatterns, 'user', 'user'