from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class UserType(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    type = models.CharField(max_length=50,null=True)

class bystander(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE,null=True)
    address = models.CharField(max_length=50,null=True)
    phone = models.CharField(max_length=50,null=True)
    image = models.ImageField(upload_to='images/', null=True)


class hospital(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE,null=True)
    address = models.CharField(max_length=50,null=True)
    phone = models.CharField(max_length=50,null=True)
    image = models.ImageField(upload_to='images/', null=True)


class Users(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE,null=True)
    address = models.CharField(max_length=50,null=True)
    phone = models.CharField(max_length=50,null=True)
    
    
class bystander_app(models.Model):
    user = models.ForeignKey(Users, on_delete=models.CASCADE,null=True)
    bystander = models.ForeignKey(bystander, on_delete=models.CASCADE,null=True)
    time = models.CharField(max_length=50,null=True)
    date = models.CharField(max_length=50,null=True)
    status = models.CharField(max_length=50,null=True)
    
class hospital_app(models.Model):
    user = models.ForeignKey(Users, on_delete=models.CASCADE,null=True)
    hospital = models.ForeignKey(hospital, on_delete=models.CASCADE,null=True)
    time = models.CharField(max_length=50,null=True)
    date = models.CharField(max_length=50,null=True)
    status = models.CharField(max_length=50,null=True)