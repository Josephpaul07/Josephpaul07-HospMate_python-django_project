from django.contrib.auth.models import User
from django.views.generic import TemplateView , View
from django.shortcuts import render
from hospitalityapp.models import Users, bystander, hospital, hospital_app, bystander_app


class IndexView(TemplateView):
    template_name = 'admin/admin_index.html'


class hospital_verify(TemplateView):
    template_name = 'admin/hospital_approvel.html'
    def get_context_data(self, **kwargs):
        context = super(hospital_verify,self).get_context_data(**kwargs)

        hospitals = hospital.objects.filter(user__last_name='0',user__is_staff='0',user__is_active='1')

        context['hospital'] = hospitals
        return context
    
class hospital_approve(View):
    def dispatch(self, request, *args, **kwargs):
        id = request.GET['id']
        user = User.objects.get(id=id)
        user.last_name='1'
        user.save()
        return render(request,'admin/admin_index.html',{'message':" Account Approved"})

class hospital_reject(View):
    def dispatch(self, request, *args, **kwargs):
        id = request.GET['id']
        user = User.objects.get(id=id)
        user.last_name='1'
        user.is_active='0'
        user.save()
        return render(request,'admin/admin_index.html',{'message':"Account Removed"})
    

class bystander_verify(TemplateView):
    template_name = 'admin/bystander_approvel.html'
    def get_context_data(self, **kwargs):
        context = super(bystander_verify,self).get_context_data(**kwargs)

        bystanders = bystander.objects.filter(user__last_name='0',user__is_staff='0',user__is_active='1')

        context['bystander'] = bystanders
        return context
    
class bystander_approve(View):
    def dispatch(self, request, *args, **kwargs):
        id = request.GET['id']
        user = User.objects.get(id=id)
        user.last_name='1'
        user.save()
        return render(request,'admin/admin_index.html',{'message':" Account Approved"})

class bystander_reject(View):
    def dispatch(self, request, *args, **kwargs):
        id = request.GET['id']
        user = User.objects.get(id=id)
        user.last_name='1'
        user.is_active='0'
        user.save()
        return render(request,'admin/admin_index.html',{'message':"Account Removed"})
    
class view_hospital(TemplateView):
    template_name = 'admin/view_hospital.html'
    def get_context_data(self, **kwargs):
        context = super(view_hospital,self).get_context_data(**kwargs)
        hospitalz = hospital.objects.filter(user__last_name='1',user__is_staff='0',user__is_active='1')

        context['hospitalz'] = hospitalz
        return context
    
class view_bystander(TemplateView):
    template_name="admin/view_bystander.html"
    def get_context_data(self, **kwargs):
        context = super(view_bystander,self).get_context_data(**kwargs)
        bystanderz = bystander.objects.filter(user__last_name='1',user__is_staff='0',user__is_active='1')

        context['bystanderz'] = bystanderz
        return context
    
class view_user(TemplateView):
    template_name="admin/view_user.html"
    def get_context_data(self, **kwargs):
        context = super(view_user,self).get_context_data(**kwargs)
        userz = Users.objects.all( )

        context['userz'] = userz
        return context
    

class view_hbooking(TemplateView):
    template_name = 'admin/view_hbooking.html'
    def get_context_data(self, **kwargs):
        context = super(view_hbooking,self).get_context_data(**kwargs)
        hoo = hospital_app.objects.filter(status='Booking Confirm')

        context ['hoo'] = hoo
        return context
    
class view_b_booking(TemplateView):
    template_name = 'admin/view_b_booking.html'
    def get_context_data(self, **kwargs):
        context = super(view_b_booking,self).get_context_data(**kwargs)
        bb = bystander_app.objects.filter(status='Booking Confirm')

        context ['bb'] = bb
        return context