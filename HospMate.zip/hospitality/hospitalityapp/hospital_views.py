from django.contrib.auth.models import User
from django.views.generic import TemplateView , View
from django.shortcuts import render
from hospitalityapp.models import bystander, Users, hospital_app, hospital


class IndexView(TemplateView):
    template_name = 'hospital/hospital_index.html'
    
class view_bystander(TemplateView):
    template_name="hospital/view_bystander.html"
    def get_context_data(self, **kwargs):
        context = super(view_bystander,self).get_context_data(**kwargs)
        bystanderz = bystander.objects.filter(user__last_name='1',user__is_staff='0',user__is_active='1')

        context['bystanderz'] = bystanderz
        return context
    
class view_user(TemplateView):
    template_name="hospital/view_user.html"
    def get_context_data(self, **kwargs):
        context = super(view_user,self).get_context_data(**kwargs)
        userz = Users.objects.all()

        context['userz'] = userz
        return context
    
class view_booking(TemplateView):
    template_name = 'hospital/view_booking.html'
    def get_context_data(self, **kwargs):
        context = super(view_booking,self).get_context_data(**kwargs)
        hos = hospital.objects.get(user_id=self.request.user.id)
        hoo = hospital_app.objects.filter(hospital_id = hos.id, status='added')

        context ['hoo'] = hoo
        return context

class app_approve(View):
    def dispatch(self, request, *args, **kwargs):
        id = request.GET['id']
        h = hospital_app.objects.get(id=id)
        h.status='Booking Confirm'
        h.save()
        return render(request,'hospital/hospital_index.html',{'message':"  Booking Confirmed"})