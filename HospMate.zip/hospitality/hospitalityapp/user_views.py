from django.contrib.auth.models import User
from django.views.generic import TemplateView , View
from django.shortcuts import render
from hospitalityapp.models import hospital, bystander, Users, bystander_app, hospital_app


class IndexView(TemplateView):
    template_name = 'user/user_index.html'
    
    
class view_hospital(TemplateView):
    template_name = 'user/view_hospital.html'
    def get_context_data(self, **kwargs):
        context = super(view_hospital, self).get_context_data(**kwargs)
        ho = hospital.objects.all()
        context['ho'] = ho
        return context
    
class view_bystanders(TemplateView):
    template_name = 'user/view_bystand.html'
    def get_context_data(self, **kwargs):
        context = super(view_bystanders, self).get_context_data(**kwargs)
        bs = bystander.objects.all()
        context['bs'] = bs
        return context
    
class add_app(TemplateView):
    template_name='user/add_app.html'
    def get_context_data(self, **kwargs):
        id =self.request.GET['id']
        context = super(add_app,self).get_context_data(**kwargs)
        cl = bystander.objects.filter(id=id)

        context['cl'] = cl
        return context
    
    def post(self , request,*args,**kwargs):
        user =  Users.objects.get(user_id=self.request.user.id)
        cr=request.POST['id']
        date= request.POST['date']
        time= request.POST['time']
        
        fee =bystander_app()
        fee.user_id = user.id
        fee.bystander_id = cr
        fee.date = date
        fee.time = time
        fee.status = 'added'
        fee.save()

        return render(request, 'user/user_index.html', {'message':"successfully Booked"})
    

   
class add_app_hos(TemplateView):
    template_name='user/add_app_hos.html'
    def get_context_data(self, **kwargs):
        id =self.request.GET['id']
        context = super(add_app_hos,self).get_context_data(**kwargs)
        hs = hospital.objects.filter(id=id)

        context['hs'] = hs
        return context
    
    def post(self , request,*args,**kwargs):
        user =  Users.objects.get(user_id=self.request.user.id)
        cr=request.POST['id']
        date= request.POST['date']
        time= request.POST['time']
        
        fee =hospital_app()
        fee.user_id = user.id
        fee.hospital_id = cr
        fee.date = date
        fee.time = time
        fee.status = 'added'
        fee.save()

        return render(request, 'user/user_index.html', {'message':"successfully Booked"})
    
class view_hbooking(TemplateView):
    template_name = 'user/view_hbooking.html'
    def get_context_data(self, **kwargs):
        context = super(view_hbooking,self).get_context_data(**kwargs)
        user =  Users.objects.get(user_id=self.request.user.id)
        hoo = hospital_app.objects.filter(user_id = user.id, status='Booking Confirm')

        context ['hoo'] = hoo
        return context
    
class view_b_booking(TemplateView):
    template_name = 'user/view_b_booking.html'
    def get_context_data(self, **kwargs):
        context = super(view_b_booking,self).get_context_data(**kwargs)
        user =  Users.objects.get(user_id=self.request.user.id)
        bb = bystander_app.objects.filter(user_id = user.id, status='Booking Confirm')

        context ['bb'] = bb
        return context